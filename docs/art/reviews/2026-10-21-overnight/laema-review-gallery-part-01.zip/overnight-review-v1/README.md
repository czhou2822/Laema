# Laema attack-art review · 21 October 2026

Start with 01-review-overview.png and 03-illustrative-motion-review.mp4. Open index.html for the offline gallery. 02-source-vs-studies.png compares representative current-source and study poses. Full PNG masters and full-sequence contact sheets are in candidates/.

## Review choices
- X1 R05: stronger eight-pose material/motion candidate. Matte materials and neutral hair; faithful transparent replacement unresolved.
- X4 R02: stronger raised high-thrust candidate. Three untimed poses.
- X5 R04: retain the full nine-pose study. R05 pose 8 is a separate useful halfway-recovery body study only. Do not adopt the whole regenerated R05 atlas. Sword continuity remains unverified; R06 blade correction was rejected.
- X2 r03b: preferred bounded rear-sweep ALTERNATIVE. Brake absorption is still understated. This does not resolve or accept the current forward-v03-art/backward-retained-geometry discrepancy. R04 brake was rejected for over-retraction and arm/grip discontinuity.
- X3 r07/r08/r09: unresolved. No replacement selected. R07 shows the intended end-on direction but a stubby blade; R08 is a clear long sword but too rearward; R09 still reads as a short blade. Source seams remain.

## Optional X4 material appendix
Optional X4 r03a palette/material study only. Ivory hair and darker leather move closer to X1 R05, with no consequential motion drift visible in independent review. Boots remain polished, the sash is duller/burgundy, leather is cooler/grayer, and face tone changes slightly. This is not a fully matched matte finish or a replacement for selected X4 R02. No alpha, gameplay, timing or runtime change. See studies/X4-optional-material-r03a.png and studies/X4-optional-material-comparison.png.

## Transparency finding
Proper light/dark alpha compositing is reasonably clean. Raw viewers exaggerate saturated edge RGB that is almost entirely at alpha 1–3/255. No faithful transparent replacement was accepted because identity, equipment and proportions drift and native registration is not preserved. Opaque R05 stays selected for review; this is not engine/filter/mipmap validation.

## What this is not
No candidate is sprite-ready, imported, or engine-validated. Opaque backgrounds are retained. Faithful transparency, pixel-level grip/weapon/stance lock and source-style matching remain open. GIF/MP4 timing is illustrative only, not combat speed or a timing proposal; replay resets are not authored recovery. The nine-pose X5 study is not a native key map.

No source/master file, runtime, hitbox, collision, timing, movement, damage, input or camera was changed. No build or engine test was run. Technical crops, fixed per-sequence scales, translations and layout were used; no repaint, masking, alpha extraction or cleanup was done for this package.

## Contents
- sources/: unchanged current v03 X1–X5 textures and approved Open identity reference.
- candidates/: unchanged selected opaque masters, full-sequence contacts, isolated R05 pose 8 crop.
- studies/: deeper X2 and X3 packages, X5 recovery comparison and rejected X1/X5 results.
- PROVENANCE.json: source commit, hashes, selection status, exact registration and timing limits.

Source snapshot: czhou2822/Laema, commit f277903b0f7f9995f9dc715a273427999af01111. These are the assigned Fire v03 textures, not historical Earth-named textures. Open is one approved identity-reference alternative, not an exclusive outfit decision. All original source files and generation rounds remain preserved unchanged outside this curated copy.

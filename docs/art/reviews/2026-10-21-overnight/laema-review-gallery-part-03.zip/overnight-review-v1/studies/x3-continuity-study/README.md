# Laema X3 continuity study

This package contains two new art-only projection experiments and their comparison against the prior r07 study and current native v03 endpoints.

## Selection

No new production replacement is selected. Keep the existing r07 reference with its known short-blade limitation; r08 and r09 remain separate experiments. R08 reads clearly as a long sword but does not reach the missing toward-camera midpoint. R09 rotates farther into the turn, yet still reads as a broad short blade rather than convincingly the same long sword in depth.

## Start here

- `before-after-diagnostic.png`: native endpoints, r07, r08 and r09 at comparable visible size.
- `native-source-context-test.png`: exact native chamber and cut with r09 inserted between them for inspection.
- `middle-weapon-detail.png`: unscaled weapon crops.
- `native-source-context-test.gif`: the context test with 500 ms per pose, not engine timing.
- `r09-equal-dwell-study.gif`: the generated triptych at equal diagnostic dwell.

The three large PNG masters are named as references or experiments, not accepted assets. `registration-and-provenance.json` records the technical transforms and unchanged source hashes. Prompt JSON files preserve both generation instructions.

## Limits

No source file, hitbox, attack direction, root motion, combat timing or gameplay resource was changed. Generated opaque backgrounds are retained. No background extraction, manual redraw or pixel cleanup was used. These are continuity studies, not production-ready sprites or validated animation frames.

Current native X3 still jumps from normalized phase 0.37149858 to 0.60950685. The excluded reversed raw pose remains excluded. Adding a visual study does not establish a new phase or authorize changing game behavior.

# X2 rear-sweep study: selected r03b

## Decision

Choose r03b as the strongest three-beat contact → follow-through → brake study. Its sword/hilt/grip and lower body remain more coherent than earlier alternatives. The final r04 brake edit was rejected: it creates stronger withdrawal, but retracts too far and turns the forearm/fist toward the viewer, breaking the established continuity.

The chosen master is copied without alteration. This is an opaque ART ALTERNATIVE, not final production animation, an accepted gameplay-direction change, or a hitbox fix.

## Open these first

1. `01-CHOSEN-r03b-opaque-master.png`: full-resolution chosen art.
2. `02-CHOSEN-native-size-three-beat-strip.png`: roughly 180px visible-body review, translation-only rear-foot registration.
3. `03-CHOSEN-slow-diagnostic.gif`: illustrative motion, not native timing. The C-to-A replay is not an authored recovery.
4. `04-before-after-r02-to-r03.png`: explains the local continuity improvement.
5. `05-REJECTED-r04-brake-comparison.png`: chosen/rejected comparison and same-coordinate grip close-ups.
6. `06-REJECTED-r04-slow-comparison.gif`: shows why greater withdrawal was not selected.

## What remains unresolved

- Brake absorption is understated: the elbow is still nearly extended. This is the next art-mechanics issue, not claimed solved.
- Exact grip/weapon proportions and planted-foot/hip pixel lock are not established. Small residual drift remains.
- The proof is opaque, and the original layout is not a validated equal-cell sprite atlas. No alpha extraction was attempted.
- This isolated arm-motion study does not establish whole-body torque or a complete attack animation.
- The current native v03 X2 forward extension and retained rearward geometry still disagree. This study leaves that design decision open.

No accepted asset, hitbox, collision, timing, movement, damage, input, camera, or runtime behavior was changed. No engine test was run. Source identity and current X2 bytes remain identical to the published source snapshot.

## Provenance

`PROVENANCE.json` records chosen/rejected history, file hashes, source commit and limitations. Diagnostic frames use technical crops, one uniform candidate scale, and rear-foot translation registration only; no painted reconstruction or independent pose rescaling. The rejected comparison preserves the original contact/follow-through pixels exactly and substitutes only a complete generated brake-frame region.
